#include <stdio.h>

double Delta(double, double, double);
double Pierw(double, double, double, int);
double* PierwZesp(double, double, double, int);
