#include <stdio.h>

void WczytajDane(void);

double a, b;

