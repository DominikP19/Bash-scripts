#include "rlin.h"

void main(int argc, char* argv[])
{
	double x;
	
	WczytajDane();
	x = -b/a;
	printf("x1 = %lf\n", x);
	return;
}
