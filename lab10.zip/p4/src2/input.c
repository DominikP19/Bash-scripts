#include "rlin.h"

void WczytajDane(void)
{
        printf("Podaj wspolczynniki rownania liniowego ax + b = 0\n");
        printf("a = ");
        scanf("%f",&a);
        printf("b = ");
        scanf("%f",&b);
	printf("\n");
        return;
}

